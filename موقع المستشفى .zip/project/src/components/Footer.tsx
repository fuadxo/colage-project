import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-blue-900 text-white py-8">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">تواصل معنا</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                <span>+123 456 789</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                <span>info@hospital.com</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                <span>شارع الرئيسي، المدينة</span>
              </div>
            </div>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">ساعات العمل</h3>
            <p>الأحد - الخميس: 8:00 صباحاً - 8:00 مساءً</p>
            <p>الجمعة - السبت: 9:00 صباحاً - 6:00 مساءً</p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">الطوارئ</h3>
            <p>خدمة 24 ساعة</p>
            <p className="text-xl font-bold">123</p>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;