import React from 'react';
import { Heart, Brain, Bone, Eye, Stethoscope } from 'lucide-react';

const Clinics = () => {
  const clinics = [
    {
      name: "عيادة القلب",
      icon: Heart,
      description: "خدمات متكاملة لتشخيص وعلاج أمراض القلب",
      news: "توفر أحدث أجهزة القسطرة القلبية"
    },
    {
      name: "عيادة الأعصاب",
      icon: Brain,
      description: "رعاية متخصصة للجهاز العصبي والدماغ",
      news: "استقبال استشاري جديد في طب الأعصاب"
    },
    {
      name: "عيادة العظام",
      icon: Bone,
      description: "علاج إصابات وأمراض العظام والمفاصل",
      news: "عمليات المنظار المتقدمة للركبة"
    },
    {
      name: "عيادة العيون",
      icon: Eye,
      description: "رعاية شاملة لصحة العين والبصر",
      news: "تقنيات جديدة لعلاج قصر النظر"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">عياداتنا</h1>
        <p className="text-xl text-gray-600">نقدم خدمات طبية متكاملة في مختلف التخصصات</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {clinics.map((clinic, index) => (
          <div key={index} className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center gap-4 mb-4">
              <clinic.icon className="h-10 w-10 text-blue-600" />
              <h2 className="text-2xl font-bold">{clinic.name}</h2>
            </div>
            <p className="text-gray-600 mb-4">{clinic.description}</p>
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-bold mb-2">آخر الأخبار</h3>
              <p>{clinic.news}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-white rounded-lg shadow-lg p-8">
        <div className="flex items-center gap-4 mb-6">
          <Stethoscope className="h-8 w-8 text-blue-600" />
          <h2 className="text-2xl font-bold">مواعيد العيادات</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-bold mb-2">الفترة الصباحية</h3>
            <p>من 9:00 صباحاً إلى 1:00 ظهراً</p>
          </div>
          <div>
            <h3 className="font-bold mb-2">الفترة المسائية</h3>
            <p>من 4:00 عصراً إلى 9:00 مساءً</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Clinics;