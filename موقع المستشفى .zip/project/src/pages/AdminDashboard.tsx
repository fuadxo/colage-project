import React, { useState } from 'react';
import { Calendar, Clock, User, Check, X, Plus, Edit, Trash, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('appointments');
  
  // حالة الحجوزات
  const [appointments, setAppointments] = useState([
    {
      id: 1,
      name: "أحمد محمد",
      age: 35,
      clinic: "عيادة القلب",
      date: "2024-03-20",
      time: "10:00",
      status: "pending"
    },
    {
      id: 2,
      name: "فاطمة أحمد",
      age: 28,
      clinic: "عيادة العيون",
      date: "2024-03-21",
      time: "14:30",
      status: "confirmed"
    }
  ]);

  // حالة الأخبار
  const [news, setNews] = useState([
    {
      id: 1,
      title: "افتتاح قسم جديد للعلاج الطبيعي",
      date: "2024-03-15",
      image: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=800",
      description: "تم افتتاح قسم جديد للعلاج الطبيعي مجهز بأحدث المعدات الطبية"
    }
  ]);

  // حالة العيادات
  const [clinics, setClinics] = useState([
    {
      id: 1,
      name: "عيادة القلب",
      description: "خدمات متكاملة لتشخيص وعلاج أمراض القلب",
      news: "توفر أحدث أجهزة القسطرة القلبية"
    }
  ]);

  // نموذج إضافة خبر جديد
  const [newNews, setNewNews] = useState({
    title: '',
    image: '',
    description: ''
  });

  // نموذج إضافة عيادة جديدة
  const [newClinic, setNewClinic] = useState({
    name: '',
    description: '',
    news: ''
  });

  const handleConfirm = (id: number) => {
    setAppointments(appointments.map(app =>
      app.id === id ? { ...app, status: "confirmed" } : app
    ));
  };

  const handleReject = (id: number) => {
    setAppointments(appointments.map(app =>
      app.id === id ? { ...app, status: "rejected" } : app
    ));
  };

  const handleAddNews = (e: React.FormEvent) => {
    e.preventDefault();
    setNews([...news, {
      id: news.length + 1,
      date: new Date().toISOString().split('T')[0],
      ...newNews
    }]);
    setNewNews({ title: '', image: '', description: '' });
  };

  const handleAddClinic = (e: React.FormEvent) => {
    e.preventDefault();
    setClinics([...clinics, {
      id: clinics.length + 1,
      ...newClinic
    }]);
    setNewClinic({ name: '', description: '', news: '' });
  };

  const handleDeleteNews = (id: number) => {
    setNews(news.filter(item => item.id !== id));
  };

  const handleDeleteClinic = (id: number) => {
    setClinics(clinics.filter(item => item.id !== id));
  };

  const handleLogout = () => {
    localStorage.removeItem('isAdminAuthenticated');
    navigate('/admin');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">لوحة التحكم</h1>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700"
        >
          <LogOut className="h-5 w-5" />
          تسجيل الخروج
        </button>
      </div>

      {/* التبويبات */}
      <div className="flex gap-4 mb-8">
        <button
          className={`px-4 py-2 rounded-lg ${activeTab === 'appointments' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
          onClick={() => setActiveTab('appointments')}
        >
          الحجوزات
        </button>
        <button
          className={`px-4 py-2 rounded-lg ${activeTab === 'news' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
          onClick={() => setActiveTab('news')}
        >
          الأخبار
        </button>
        <button
          className={`px-4 py-2 rounded-lg ${activeTab === 'clinics' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
          onClick={() => setActiveTab('clinics')}
        >
          العيادات
        </button>
      </div>

      {/* محتوى التبويبات */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        {/* قسم الحجوزات */}
        {activeTab === 'appointments' && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-6 py-3 text-right">المريض</th>
                  <th className="px-6 py-3 text-right">العمر</th>
                  <th className="px-6 py-3 text-right">العيادة</th>
                  <th className="px-6 py-3 text-right">التاريخ</th>
                  <th className="px-6 py-3 text-right">الوقت</th>
                  <th className="px-6 py-3 text-right">الحالة</th>
                  <th className="px-6 py-3 text-right">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {appointments.map((appointment) => (
                  <tr key={appointment.id} className="border-b">
                    <td className="px-6 py-4">{appointment.name}</td>
                    <td className="px-6 py-4">{appointment.age}</td>
                    <td className="px-6 py-4">{appointment.clinic}</td>
                    <td className="px-6 py-4">{appointment.date}</td>
                    <td className="px-6 py-4">{appointment.time}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-full text-sm ${
                        appointment.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                        appointment.status === 'rejected' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {appointment.status === 'confirmed' ? 'تم التأكيد' :
                         appointment.status === 'rejected' ? 'مرفوض' :
                         'قيد الانتظار'}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      {appointment.status === 'pending' && (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleConfirm(appointment.id)}
                            className="p-2 bg-green-100 text-green-600 rounded-full hover:bg-green-200"
                          >
                            <Check className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => handleReject(appointment.id)}
                            className="p-2 bg-red-100 text-red-600 rounded-full hover:bg-red-200"
                          >
                            <X className="h-5 w-5" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* قسم الأخبار */}
        {activeTab === 'news' && (
          <div>
            <form onSubmit={handleAddNews} className="mb-8 bg-gray-50 p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">إضافة خبر جديد</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">عنوان الخبر</label>
                  <input
                    type="text"
                    value={newNews.title}
                    onChange={(e) => setNewNews({...newNews, title: e.target.value})}
                    className="w-full p-2 border rounded"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">رابط الصورة</label>
                  <input
                    type="url"
                    value={newNews.image}
                    onChange={(e) => setNewNews({...newNews, image: e.target.value})}
                    className="w-full p-2 border rounded"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">وصف الخبر</label>
                  <textarea
                    value={newNews.description}
                    onChange={(e) => setNewNews({...newNews, description: e.target.value})}
                    className="w-full p-2 border rounded"
                    rows={3}
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                  إضافة الخبر
                </button>
              </div>
            </form>

            <div className="space-y-4">
              {news.map((item) => (
                <div key={item.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="text-lg font-bold">{item.title}</h4>
                    <button
                      onClick={() => handleDeleteNews(item.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash className="h-5 w-5" />
                    </button>
                  </div>
                  <p className="text-gray-600 mb-2">{item.date}</p>
                  <img src={item.image} alt={item.title} className="w-full h-48 object-cover rounded mb-2" />
                  <p>{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* قسم العيادات */}
        {activeTab === 'clinics' && (
          <div>
            <form onSubmit={handleAddClinic} className="mb-8 bg-gray-50 p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">إضافة عيادة جديدة</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">اسم العيادة</label>
                  <input
                    type="text"
                    value={newClinic.name}
                    onChange={(e) => setNewClinic({...newClinic, name: e.target.value})}
                    className="w-full p-2 border rounded"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">وصف العيادة</label>
                  <textarea
                    value={newClinic.description}
                    onChange={(e) => setNewClinic({...newClinic, description: e.target.value})}
                    className="w-full p-2 border rounded"
                    rows={3}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">أخبار العيادة</label>
                  <input
                    type="text"
                    value={newClinic.news}
                    onChange={(e) => setNewClinic({...newClinic, news: e.target.value})}
                    className="w-full p-2 border rounded"
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                  إضافة العيادة
                </button>
              </div>
            </form>

            <div className="space-y-4">
              {clinics.map((clinic) => (
                <div key={clinic.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="text-lg font-bold">{clinic.name}</h4>
                    <button
                      onClick={() => handleDeleteClinic(clinic.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash className="h-5 w-5" />
                    </button>
                  </div>
                  <p className="mb-2">{clinic.description}</p>
                  <p className="text-gray-600">{clinic.news}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;