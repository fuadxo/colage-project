import React from 'react';
import { Clock, Users, Stethoscope } from 'lucide-react';

const Home = () => {
  const news = [
    {
      title: "افتتاح قسم جديد للعلاج الطبيعي",
      date: "2024-03-15",
      image: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=800",
      description: "تم افتتاح قسم جديد للعلاج الطبيعي مجهز بأحدث المعدات الطبية"
    },
    {
      title: "حملة التطعيم السنوية",
      date: "2024-03-10",
      image: "https://images.unsplash.com/photo-1584515933487-779824d29309?auto=format&fit=crop&q=80&w=800",
      description: "انطلاق حملة التطعيم السنوية ضد الإنفلونزا الموسمية"
    }
  ];

  return (
    <div className="space-y-12 py-8">
      {/* Hero Section */}
      <div className="relative h-[500px]">
        <img
          src="https://images.unsplash.com/photo-1538108149393-fbbd81895907?auto=format&fit=crop&q=80&w=2000"
          alt="Hospital"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-blue-900/70 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-6xl font-bold mb-4">المستشفى الجمهوري</h1>
            <p className="text-xl md:text-2xl">نقدم أفضل رعاية صحية لمرضانا</p>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center p-6 bg-white rounded-lg shadow-lg">
            <Clock className="h-12 w-12 mx-auto text-blue-600 mb-4" />
            <h3 className="text-xl font-bold mb-2">خدمة 24/7</h3>
            <p>نقدم خدماتنا على مدار الساعة</p>
          </div>
          <div className="text-center p-6 bg-white rounded-lg shadow-lg">
            <Users className="h-12 w-12 mx-auto text-blue-600 mb-4" />
            <h3 className="text-xl font-bold mb-2">طاقم طبي متميز</h3>
            <p>نخبة من الأطباء والممرضين</p>
          </div>
          <div className="text-center p-6 bg-white rounded-lg shadow-lg">
            <Stethoscope className="h-12 w-12 mx-auto text-blue-600 mb-4" />
            <h3 className="text-xl font-bold mb-2">تجهيزات حديثة</h3>
            <p>أحدث المعدات والتقنيات الطبية</p>
          </div>
        </div>
      </div>

      {/* News Section */}
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">أخبار المستشفى</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {news.map((item, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img src={item.image} alt={item.title} className="w-full h-48 object-cover" />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-gray-600 mb-2">{item.date}</p>
                <p>{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Home;