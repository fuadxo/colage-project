import React, { useState } from 'react';
import { Calendar, Clock, User, Activity } from 'lucide-react';

const Appointment = () => {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    clinic: '',
    date: '',
    time: ''
  });

  const clinics = [
    "عيادة القلب",
    "عيادة الأعصاب",
    "عيادة العظام",
    "عيادة العيون"
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // حفظ الحجز في localStorage
    const appointments = JSON.parse(localStorage.getItem('appointments') || '[]');
    const newAppointment = {
      id: appointments.length + 1,
      ...formData,
      status: 'pending'
    };
    appointments.push(newAppointment);
    localStorage.setItem('appointments', JSON.stringify(appointments));
    
    // تنظيف النموذج
    setFormData({
      name: '',
      age: '',
      clinic: '',
      date: '',
      time: ''
    });
    
    alert('تم إرسال طلب الحجز بنجاح');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">حجز موعد</h1>
        <p className="text-xl text-gray-600">يرجى ملء النموذج التالي لحجز موعد في العيادة</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-lg p-8">
        <div className="space-y-6">
          <div>
            <label className="flex items-center gap-2 text-lg font-medium mb-2">
              <User className="h-5 w-5 text-blue-600" />
              اسم المريض
            </label>
            <input
              type="text"
              name="name"
              required
              value={formData.name}
              onChange={handleChange}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="الاسم الكامل"
            />
          </div>

          <div>
            <label className="flex items-center gap-2 text-lg font-medium mb-2">
              <User className="h-5 w-5 text-blue-600" />
              العمر
            </label>
            <input
              type="number"
              name="age"
              required
              value={formData.age}
              onChange={handleChange}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="العمر"
            />
          </div>

          <div>
            <label className="flex items-center gap-2 text-lg font-medium mb-2">
              <Activity className="h-5 w-5 text-blue-600" />
              العيادة
            </label>
            <select
              name="clinic"
              required
              value={formData.clinic}
              onChange={handleChange}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="">اختر العيادة</option>
              {clinics.map((clinic, index) => (
                <option key={index} value={clinic}>{clinic}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="flex items-center gap-2 text-lg font-medium mb-2">
              <Calendar className="h-5 w-5 text-blue-600" />
              تاريخ الموعد
            </label>
            <input
              type="date"
              name="date"
              required
              value={formData.date}
              onChange={handleChange}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="flex items-center gap-2 text-lg font-medium mb-2">
              <Clock className="h-5 w-5 text-blue-600" />
              وقت الموعد
            </label>
            <input
              type="time"
              name="time"
              required
              value={formData.time}
              onChange={handleChange}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition duration-200"
          >
            تأكيد الحجز
          </button>
        </div>
      </form>
    </div>
  );
}

export default Appointment;